

<?php $__env->startSection('title', 'nosotros'); ?>

<?php $__env->startSection('content'); ?>
    
    
    <h1 class="my-4">NOSOTROS</h1>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gigaweb\proyect\resources\views/nosotros/index.blade.php ENDPATH**/ ?>