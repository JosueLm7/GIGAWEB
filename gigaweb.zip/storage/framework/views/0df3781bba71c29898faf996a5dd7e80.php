

<?php $__env->startSection('title', 'Detalles del Cliente'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="my-4">Detalles del Cliente</h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($cliente->nombres); ?> <?php echo e($cliente->apellido_paterno); ?> <?php echo e($cliente->apellido_materno); ?></h5>
            <p class="card-text">Correo Electrónico: <?php echo e($cliente->correo_electronico); ?></p>
            <p class="card-text">Teléfono: <?php echo e($cliente->telefono); ?></p>
            <p class="card-text">Dirección: <?php echo e($cliente->direccion); ?></p>
            <a href="<?php echo e(route('clientes.edit', $cliente)); ?>" class="btn btn-warning">Editar</a>
            <form action="<?php echo e(route('clientes.destroy', $cliente)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Eliminar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gigaweb\proyect\resources\views/clientes/show.blade.php ENDPATH**/ ?>