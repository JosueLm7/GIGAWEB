

<?php $__env->startSection('title', 'Notificaciones de Clientes'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Notificaciones de Clientes</h1>

    <a href="<?php echo e(route('notificaciones.clientes.create')); ?>" class="btn btn-primary">Enviar Nueva Notificación</a>

    <table class="table">
        <thead>
            <tr>
                <th>Cliente</th>
                <th>Mensaje</th>
                <th>Leída</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $notificacionesClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($notificacion->cliente->nombres); ?></td>
                    <td><?php echo e($notificacion->mensaje); ?></td>
                    <td><?php echo e($notificacion->leida ? 'Sí' : 'No'); ?></td>
                    <td>
                        <a href="<?php echo e(route('notificaciones.clientes.edit', $notificacion)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('notificaciones.clientes.destroy', $notificacion)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gigaweb\proyect\resources\views/notificaciones/clientes/index.blade.php ENDPATH**/ ?>