

<?php $__env->startSection('title', 'Contáctanos'); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
       <h2 class="my-4">Correo Electrónico</h2>
       <p>Este es el primer correo que mandamos por Laravel.</p>
       <p><strong>Nombre:</strong> <?php echo e($data['name']); ?></p>
       <p><strong>Correo:</strong> <?php echo e($data['email']); ?></p>
       <p><strong>Mensaje:</strong> <?php echo e($data['message']); ?></p>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Downloads\Melendez_Semana9\proyect\resources\views/emails/contactanos.blade.php ENDPATH**/ ?>