<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class ValidateClientRegistrationTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_example(): void
    {
        $this->assertTrue(true);
    }
}
