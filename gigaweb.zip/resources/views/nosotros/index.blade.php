@extends('layouts.app')

@section('title', 'nosotros')

@section('content')
    
    
    <h1 class="my-4">NOSOTROS</h1>
    

@endsection
